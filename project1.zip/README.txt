CS144 Project Part 1
Nathan Tung
004-059-195
Julian Yang
904-121-089
