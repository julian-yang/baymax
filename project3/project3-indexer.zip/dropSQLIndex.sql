DROP INDEX sp_index ON Locations;

DROP TABLE IF EXISTS Locations;